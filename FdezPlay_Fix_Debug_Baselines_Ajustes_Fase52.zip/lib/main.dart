import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'app/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Evita que queden activadas ayudas visuales de depuración como:
  // baselines, bordes de layout, punteros o repintado de widgets.
  // Esto solo aplica en debug; en release estas opciones no se muestran.
  assert(() {
    debugPaintBaselinesEnabled = false;
    debugPaintSizeEnabled = false;
    debugPaintPointersEnabled = false;
    debugRepaintRainbowEnabled = false;
    return true;
  }());

  final imageCache = PaintingBinding.instance.imageCache;
  imageCache.maximumSize = 300;
  imageCache.maximumSizeBytes = 80 * 1024 * 1024;

  runApp(const FdezPlayApp());
}
